/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  THANH PHUONG
 * Created: Feb 28, 2025
 */

Create database Workshop1_PRJ301
Use Workshop1_PRJ301

CREATE TABLE tblUsers (
    Username VARCHAR(50) PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Password VARCHAR(255) NOT NULL,
    Role VARCHAR(20) NOT NULL CHECK (Role IN ('Founder', 'Team Member'))
);



INSERT INTO tblUsers(Username, Name, Password, Role)
VALUES
-- 7 Founders
('Phuong2004', 'Thanh Phuong', '12345678', 'Founder'),
('Bao20345', 'Chi Bao', 'Secretpass', 'Founder'),
('MaGaming2324','Quang Tai','QuangTai12345','Founder'),
('HieuCEO', 'Ngoc Hieu', 'HieuPass99', 'Founder'),
('LinhStart', 'Hoang Linh', 'Linh2025', 'Founder'),
('AnVision', 'Duy An', 'AnSecurePass', 'Founder'),
('MaiNextGen', 'Mai Thanh', 'MaiFuture123', 'Founder'),

-- 20 Team Members
('User01', 'Nguyen Van A', 'PassUser01', 'Team Member'),
('User02', 'Tran Thi B', 'PassUser02', 'Team Member'),
('User03', 'Le Van C', 'PassUser03', 'Team Member'),
('User04', 'Pham Minh D', 'PassUser04', 'Team Member'),
('User05', 'Hoang Kim E', 'PassUser05', 'Team Member'),
('User06', 'Doan Thanh F', 'PassUser06', 'Team Member'),
('User07', 'Vo Duc G', 'PassUser07', 'Team Member'),
('User08', 'Bui Hong H', 'PassUser08', 'Team Member'),
('User09', 'Ngo Quang I', 'PassUser09', 'Team Member'),
('User10', 'Dinh Tuan J', 'PassUser10', 'Team Member'),
('User11', 'Ly Gia K', 'PassUser11', 'Team Member'),
('User12', 'Cao Phuong L', 'PassUser12', 'Team Member'),
('User13', 'Trinh Bao M', 'PassUser13', 'Team Member'),
('User14', 'Duong Anh N', 'PassUser14', 'Team Member'),
('User15', 'To Vinh O', 'PassUser15', 'Team Member'),
('User16', 'Huynh My P', 'PassUser16', 'Team Member'),
('User17', 'Ngo Tien Q', 'PassUser17', 'Team Member'),
('User18', 'Phan Minh R', 'PassUser18', 'Team Member'),
('User19', 'Vu Huu S', 'PassUser19', 'Team Member'),
('User20', 'Khong Trung T', 'PassUser20', 'Team Member');


